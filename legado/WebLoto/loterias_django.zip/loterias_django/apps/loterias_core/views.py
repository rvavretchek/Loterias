from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.core.paginator import Paginator
from django.db.models import Count, Avg
from .models import JogoGerado, JOGOS_CONFIG, JOGOS_COM_REGRA_SEQUENCIA
from .utils import (
    gerar_aposta, verificar_jogo_repetido, contar_pares_sequenciais,
    calcular_estatisticas
)


def home(request):
    """Pagina inicial com dashboard."""
    if request.user.is_authenticated:
        # Estatisticas do usuario
        total_jogos = JogoGerado.objects.filter(usuario=request.user).count()
        jogos_por_tipo = JogoGerado.objects.filter(usuario=request.user).values('jogo').annotate(
            total=Count('id')
        ).order_by('-total')

        ultimos_jogos = JogoGerado.objects.filter(usuario=request.user).select_related('usuario')[:10]

        context = {
            'total_jogos': total_jogos,
            'jogos_por_tipo': jogos_por_tipo,
            'ultimos_jogos': ultimos_jogos,
            'jogos_disponiveis': JOGOS_CONFIG,
        }
    else:
        context = {
            'jogos_disponiveis': JOGOS_CONFIG,
        }

    return render(request, 'loterias_core/home.html', context)


@login_required
def gerar_jogo(request):
    """View para gerar novo jogo."""
    if request.method != 'POST':
        return redirect('home')

    jogo_sel = request.POST.get('jogo')
    concurso = request.POST.get('concurso', '').strip()

    if not jogo_sel or not concurso:
        messages.error(request, 'Selecione o jogo e informe o numero do concurso.')
        return redirect('home')

    if jogo_sel not in JOGOS_CONFIG:
        messages.error(request, 'Jogo invalido.')
        return redirect('home')

    # Verificar se concurso ja existe para este usuario e jogo
    if JogoGerado.objects.filter(usuario=request.user, jogo=jogo_sel, concurso=concurso).exists():
        messages.warning(request, f'Ja existe um jogo de {jogo_sel} para o concurso {concurso}.')

    tentativas = 0
    max_tentativas = 1000
    novo_jogo = None
    novos_trevos = None

    while tentativas < max_tentativas:
        nums, trevos = gerar_aposta(jogo_sel, request.user)

        if verificar_jogo_repetido(request.user, jogo_sel, nums, trevos):
            tentativas += 1
            continue

        novo_jogo = nums
        novos_trevos = trevos
        break

    if not novo_jogo:
        messages.warning(request, 'Nao foi possivel gerar um jogo unico apos muitas tentativas.')
        return redirect('home')

    # Calcular pares sequenciais
    pares_seq = contar_pares_sequenciais(novo_jogo)

    # Salvar no banco de dados
    jogo = JogoGerado.objects.create(
        usuario=request.user,
        jogo=jogo_sel,
        concurso=concurso,
        numeros=novo_jogo,
        trevos=novos_trevos if novos_trevos else [],
        pares_sequenciais=pares_seq
    )

    messages.success(request, f'Jogo de {jogo_sel} gerado com sucesso para o concurso {concurso}!')

    return redirect('detalhes_jogo', pk=jogo.pk)


@login_required
def detalhes_jogo(request, pk):
    """Pagina de detalhes de um jogo."""
    jogo = get_object_or_404(JogoGerado, pk=pk, usuario=request.user)

    # Buscar jogos anteriores do mesmo tipo para contexto de sequencia
    jogos_anteriores = JogoGerado.objects.filter(
        usuario=request.user,
        jogo=jogo.jogo
    ).exclude(pk=pk).order_by('-criado_em')[:5]

    context = {
        'jogo': jogo,
        'jogos_anteriores': jogos_anteriores,
        'aplica_regra_sequencia': jogo.jogo in JOGOS_COM_REGRA_SEQUENCIA,
    }

    return render(request, 'loterias_core/detalhes_jogo.html', context)


@login_required
def historico(request):
    """Pagina de historico de jogos."""
    jogos_list = JogoGerado.objects.filter(usuario=request.user).select_related('usuario')

    # Filtros
    jogo_filtro = request.GET.get('jogo')
    if jogo_filtro and jogo_filtro in JOGOS_CONFIG:
        jogos_list = jogos_list.filter(jogo=jogo_filtro)

    # Ordenacao
    ordenacao = request.GET.get('ordenacao', '-criado_em')
    jogos_list = jogos_list.order_by(ordenacao)

    # Paginacao
    paginator = Paginator(jogos_list, 20)
    page_number = request.GET.get('page')
    jogos = paginator.get_page(page_number)

    context = {
        'jogos': jogos,
        'jogos_disponiveis': JOGOS_CONFIG,
        'jogo_filtro': jogo_filtro,
        'ordenacao': ordenacao,
    }

    return render(request, 'loterias_core/historico.html', context)


@login_required
def refazer_jogo(request, pk):
    """Refaz um jogo existente gerando novos numeros."""
    jogo_original = get_object_or_404(JogoGerado, pk=pk, usuario=request.user)

    tentativas = 0
    max_tentativas = 1000
    novo_jogo = None
    novos_trevos = None

    while tentativas < max_tentativas:
        nums, trevos = gerar_aposta(jogo_original.jogo, request.user)

        if verificar_jogo_repetido(request.user, jogo_original.jogo, nums, trevos):
            tentativas += 1
            continue

        novo_jogo = nums
        novos_trevos = trevos
        break

    if not novo_jogo:
        messages.warning(request, 'Nao foi possivel gerar um jogo unico.')
        return redirect('detalhes_jogo', pk=pk)

    pares_seq = contar_pares_sequenciais(novo_jogo)

    # Criar novo jogo baseado no original
    novo_registro = JogoGerado.objects.create(
        usuario=request.user,
        jogo=jogo_original.jogo,
        concurso=jogo_original.concurso,
        numeros=novo_jogo,
        trevos=novos_trevos if novos_trevos else [],
        pares_sequenciais=pares_seq
    )

    messages.success(request, f'Novo jogo de {jogo_original.jogo} gerado com sucesso!')
    return redirect('detalhes_jogo', pk=novo_registro.pk)


@login_required
def estatisticas(request):
    """Pagina de estatisticas do usuario."""
    estatisticas_por_jogo = {}

    for jogo_nome in JOGOS_CONFIG.keys():
        stats = calcular_estatisticas(request.user, jogo_nome)
        if stats:
            estatisticas_por_jogo[jogo_nome] = stats

    # Estatisticas gerais
    total_geral = JogoGerado.objects.filter(usuario=request.user).count()

    context = {
        'estatisticas': estatisticas_por_jogo,
        'total_geral': total_geral,
        'jogos_disponiveis': JOGOS_CONFIG,
    }

    return render(request, 'loterias_core/estatisticas.html', context)


@login_required
@require_POST
def excluir_jogo(request, pk):
    """Exclui um jogo do historico."""
    jogo = get_object_or_404(JogoGerado, pk=pk, usuario=request.user)
    jogo.delete()
    messages.success(request, 'Jogo excluido com sucesso!')
    return redirect('historico')


@login_required
def api_gerar_jogo(request):
    """API endpoint para gerar jogo via AJAX."""
    if request.method != 'POST':
        return JsonResponse({'error': 'Metodo nao permitido'}, status=405)

    import json
    data = json.loads(request.body)
    jogo_sel = data.get('jogo')
    concurso = data.get('concurso', '').strip()

    if not jogo_sel or not concurso:
        return JsonResponse({'error': 'Dados incompletos'}, status=400)

    nums, trevos = gerar_aposta(jogo_sel, request.user)
    pares_seq = contar_pares_sequenciais(nums)

    # Verificar repeticao
    repetido = verificar_jogo_repetido(request.user, jogo_sel, nums, trevos)

    return JsonResponse({
        'numeros': nums,
        'trevos': trevos,
        'pares_sequenciais': pares_seq,
        'repetido': repetido,
    })
