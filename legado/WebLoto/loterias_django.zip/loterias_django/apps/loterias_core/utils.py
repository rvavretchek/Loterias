import random
from .models import JogoGerado, JOGOS_CONFIG, JOGOS_COM_REGRA_SEQUENCIA, INTERVALO_MIN_SEQUENCIA


def contar_pares_sequenciais(numeros):
    """Conta quantos pares de numeros consecutivos existem na lista ordenada."""
    if len(numeros) < 2:
        return 0
    pares = 0
    i = 0
    nums_sorted = sorted(numeros)
    while i < len(nums_sorted) - 1:
        if nums_sorted[i + 1] == nums_sorted[i] + 1:
            pares += 1
            i += 2  # Pula o proximo para nao contar triplas como 2 pares
        else:
            i += 1
    return pares


def ultimos_jogos_tiveram_sequencia(usuario, jogo_nome, intervalo=INTERVALO_MIN_SEQUENCIA):
    """Verifica se nos ultimos N jogos do mesmo tipo houve algum par sequencial."""
    ultimos = JogoGerado.objects.filter(
        usuario=usuario,
        jogo=jogo_nome
    ).order_by('-criado_em')[:intervalo]

    for jogo in ultimos:
        if contar_pares_sequenciais(jogo.numeros) > 0:
            return True
    return False


def gerar_aposta(nome_jogo, usuario=None):
    """Gera uma aposta valida respeitando as regras de sequencia."""
    config = JOGOS_CONFIG.get(nome_jogo)
    if not config:
        return None, None

    aplica_regra_sequencia = nome_jogo in JOGOS_COM_REGRA_SEQUENCIA

    # Para jogos com regra de sequencia, verificar se os ultimos jogos ja tiveram sequencia
    if aplica_regra_sequencia and usuario is not None:
        bloquear_sequencias = ultimos_jogos_tiveram_sequencia(usuario, nome_jogo)
    else:
        bloquear_sequencias = False

    max_tentativas = 10000
    tentativa = 0

    while tentativa < max_tentativas:
        tentativa += 1
        resultado_jogo = []
        while len(resultado_jogo) < config['apostas']:
            numero = random.randint(1, config['numeros'])
            if numero not in resultado_jogo:
                resultado_jogo.append(numero)

        resultado_jogo.sort()

        if aplica_regra_sequencia:
            pares = contar_pares_sequenciais(resultado_jogo)

            if bloquear_sequencias:
                # Nos ultimos N jogos ja houve sequencia, este nao pode ter nenhuma
                if pares > 0:
                    continue
            else:
                # Pode ter no maximo 1 par sequencial
                if pares > 1:
                    continue

        # Para Lotomania e Lotofacil, nao aplica regra nenhuma de sequencia
        break

    resultado_trevos = []
    if config['qtd_trevos'] > 0:
        while len(resultado_trevos) < config['trevos']:
            trevo = random.randint(1, config['qtd_trevos'])
            if trevo not in resultado_trevos:
                resultado_trevos.append(trevo)
        resultado_trevos.sort()

    return resultado_jogo, resultado_trevos


def verificar_jogo_repetido(usuario, jogo_nome, numeros, trevos):
    """Verifica se um jogo identico ja foi gerado pelo usuario."""
    return JogoGerado.objects.filter(
        usuario=usuario,
        jogo=jogo_nome,
        numeros=numeros,
        trevos=trevos if trevos else []
    ).exists()


def calcular_estatisticas(usuario, jogo_nome):
    """Calcula estatisticas para um tipo de jogo especifico."""
    jogos = JogoGerado.objects.filter(usuario=usuario, jogo=jogo_nome)
    total = jogos.count()

    if total == 0:
        return None

    com_sequencia = jogos.filter(pares_sequenciais__gt=0).count()

    # Calcular numeros mais frequentes
    frequencia = {}
    for jogo in jogos:
        for num in jogo.numeros:
            frequencia[num] = frequencia.get(num, 0) + 1

    # Top 10 numeros mais frequentes
    mais_frequentes = sorted(frequencia.items(), key=lambda x: x[1], reverse=True)[:10]

    return {
        'total': total,
        'com_sequencia': com_sequencia,
        'sem_sequencia': total - com_sequencia,
        'mais_frequentes': mais_frequentes,
        'percentual_sequencia': (com_sequencia / total * 100) if total > 0 else 0
    }
